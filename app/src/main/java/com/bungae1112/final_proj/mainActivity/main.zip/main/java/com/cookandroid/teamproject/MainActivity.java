package com.cookandroid.teamproject;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Cursor cur;
        EditText EditText_StoreName = (EditText) findViewById(R.id.StoreName);
        ImageView StoreImage = (ImageView) findViewById(R.id.imageView_Store);
        Button btnReservation = (Button) findViewById(R.id.btnReservation);
        Button btnSeat = (Button) findViewById(R.id.btnSeat) ;

//        EditText_StoreName = cur.getColumnName(1)

//        StoreImage.setImageURI();

        //예약하기 클릭 시
        btnReservation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent =new Intent(getApplicationContext(), ReservationActivity.class);
//                startActivity(intent);
            }
        });

        //좌석 수 클릭 시
        btnSeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //팝업 창 이미지 (코딩)

                //뒷배경 흐리기
//                WindowManager.LayoutParams layoutParams= new WindowManager.LayoutParams();
//
//                layoutParams.flags= WindowManager.LayoutParams.FLAG_DIM_BEHIND;
//
//                layoutParams.dimAmount= 0.7f;getWindow().setAttributes(layoutParams);
//
//                setContentView(R.layout.layout_name);
            }
        });





//        ===== DB
    }


}
