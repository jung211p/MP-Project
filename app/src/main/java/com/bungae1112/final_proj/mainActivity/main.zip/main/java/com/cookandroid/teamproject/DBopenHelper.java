package com.cookandroid.teamproject;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBopenHelper {
    private static final String DATABASE_NAME = "test.db";
    private static final int DATABASE_VERSION = 1;
    public static SQLiteDatabase mDB;
    private DB mDBhelper;
    private Context mContext;


    public class DB extends SQLiteOpenHelper {


        public DB(Context context,String name.CursorFactory factory,int version){
            super(context,name,factory,version);
        }

        public void onCreate(SQLiteDatabase db){
            db.execSQL("CREATE TABLE Test(_Num int," +
                    "Store_Name TEXT," +
                    " Store_PhoneNum TEXT," +
                    "Store_Menu);" );
        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
            db.execSQL("DROP TABLE IF EXISTS STORE;");
            onCreate(db);
        }



    }

    public DBopenHelper(Context context){
        this.mContext = context;
    }

    public DBopenHelper open() throws SQLException{
        mDBhelper = new DB(mContext, DATABASE_NAME,DATABASE_VERSION);
        return null;
    }
}
