package com.cookandroid.teamproject;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class TestActivity extends AppCompatActivity {

    SQLiteDatabase db;
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);

        final EditText ET_N = (EditText) findViewById(R.id.ET_name);
        final EditText ET_PN = (EditText) findViewById(R.id.ET_PhoneNum);
        final EditText ET_M = (EditText) findViewById(R.id.ET_menu);
        Button btnUpdate = (Button) findViewById(R.id.btnUpdate);

        final DB dbmanager = DB.getInstance(this);

        btnUpdate.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                ContentValues addRowV = new ContentValues();
                addRowV.put("Store_Name",ET_N.getText().toString());
                addRowV.put("Store_PhoneNum",ET_PN.getText().toString());
                addRowV.put("Store_Menu",ET_M.getText().toString());

                dbmanager.add(addRowV);
            }
        });

    }
}
